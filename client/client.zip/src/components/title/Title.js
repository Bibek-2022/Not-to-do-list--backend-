import React from "react";

export const Title = () => {
	return <h1 className="text-center py-5">My Not To Do list</h1>;
};
